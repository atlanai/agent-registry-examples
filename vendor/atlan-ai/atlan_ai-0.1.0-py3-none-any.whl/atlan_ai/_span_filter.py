"""Export allowlist (SPEC.md §4).

A span is exported iff: its instrumentation scope is the SDK's own, OR any
attribute key starts with "gen_ai.", OR its scope matches a known prefix
boundary-aware (scope == p or scope.startswith(p + ".")).

The canonical prefix list is mirrored in testdata/conformance/allowlist-v1.json;
tests enforce the two stay identical.
"""

from __future__ import annotations

from opentelemetry.sdk.trace import ReadableSpan

ATLAN_SDK_SCOPE = "atlan-sdk"

KNOWN_INSTRUMENTATION_SCOPE_PREFIXES: tuple[str, ...] = (
    "agent_framework",
    "ai",
    "atlan-sdk",
    "autogen-core",
    "haystack",
    "langfuse-sdk",
    "langsmith",
    "litellm",
    "openinference",
    "opentelemetry.instrumentation.agno",
    "opentelemetry.instrumentation.alephalpha",
    "opentelemetry.instrumentation.anthropic",
    "opentelemetry.instrumentation.bedrock",
    "opentelemetry.instrumentation.cohere",
    "opentelemetry.instrumentation.crewai",
    "opentelemetry.instrumentation.google_generativeai",
    "opentelemetry.instrumentation.groq",
    "opentelemetry.instrumentation.haystack",
    "opentelemetry.instrumentation.langchain",
    "opentelemetry.instrumentation.llamaindex",
    "opentelemetry.instrumentation.mistralai",
    "opentelemetry.instrumentation.ollama",
    "opentelemetry.instrumentation.openai",
    "opentelemetry.instrumentation.openai_agents",
    "opentelemetry.instrumentation.openai_v2",
    "opentelemetry.instrumentation.replicate",
    "opentelemetry.instrumentation.sagemaker",
    "opentelemetry.instrumentation.together",
    "opentelemetry.instrumentation.transformers",
    "opentelemetry.instrumentation.vertexai",
    "opentelemetry.instrumentation.voyageai",
    "opentelemetry.instrumentation.watsonx",
    "opentelemetry.instrumentation.writer",
    "pydantic-ai",
    "strands-agents",
    "vllm",
)


def _scope_name(span: ReadableSpan) -> str:
    scope = span.instrumentation_scope
    return scope.name if scope is not None and scope.name else ""


def is_atlan_sdk_span(span: ReadableSpan) -> bool:
    return _scope_name(span) == ATLAN_SDK_SCOPE


def is_genai_span(span: ReadableSpan) -> bool:
    attributes = span.attributes or {}
    return any(key.startswith("gen_ai.") for key in attributes)


def is_known_instrumentor_span(span: ReadableSpan) -> bool:
    scope = _scope_name(span)
    if not scope:
        return False
    return any(
        scope == prefix or scope.startswith(prefix + ".")
        for prefix in KNOWN_INSTRUMENTATION_SCOPE_PREFIXES
    )


def default_should_export(span: ReadableSpan) -> bool:
    return is_atlan_sdk_span(span) or is_genai_span(span) or is_known_instrumentor_span(span)
