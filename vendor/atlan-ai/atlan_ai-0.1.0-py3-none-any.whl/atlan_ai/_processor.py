"""The SDK span processor (SPEC.md §4, §6.2).

A BatchSpanProcessor subclass tuned for GenAI span weight (default batch 64, not
OTel's 512) that (a) stamps propagated attributes onto every span at start —
including spans created by third-party instrumentation sharing the provider —
and (b) applies the export allowlist at end. Filtering affects export only;
filtered spans still parent children normally (SPEC.md §4.4).
"""

from __future__ import annotations

import logging
from collections.abc import Callable

from opentelemetry.context import Context
from opentelemetry.sdk.trace import ReadableSpan, Span
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SpanExporter

from atlan_ai import _semconv as sc
from atlan_ai._masking import MaskFunction, apply_mask
from atlan_ai._propagation import propagated_attributes_from_context
from atlan_ai._span_filter import default_should_export

logger = logging.getLogger("atlan_ai")


class AtlanSpanProcessor(BatchSpanProcessor):
    def __init__(
        self,
        span_exporter: SpanExporter,
        *,
        flush_at: int = 64,
        flush_interval_s: float = 5.0,
        timeout_s: float = 30.0,
        should_export_span: Callable[[ReadableSpan], bool] | None = None,
        trace_content: bool = True,
        mask: MaskFunction | None = None,
    ) -> None:
        super().__init__(
            span_exporter,
            max_export_batch_size=flush_at,
            schedule_delay_millis=int(flush_interval_s * 1000),
            export_timeout_millis=int(timeout_s * 1000),
        )
        self._should_export = should_export_span or default_should_export
        self._trace_content = trace_content
        self._mask = mask

    def on_start(self, span: Span, parent_context: Context | None = None) -> None:
        try:
            attributes = propagated_attributes_from_context(
                parent_context, include_content=self._trace_content
            )
            if attributes and self._mask is not None:
                # SPEC.md §8.2: the data-level mask also covers propagated metadata.
                for key in list(attributes):
                    if key.startswith(sc.ATLAN_METADATA_PREFIX):
                        masked = apply_mask(self._mask, attributes[key])
                        if not isinstance(masked, (str, bool, int, float)):
                            masked = str(masked)
                        attributes[key] = masked
            if attributes:
                span.set_attributes(attributes)
        except Exception:  # never break user spans on enrichment bugs (SPEC.md §10.5)
            logger.debug("atlan_ai: propagated-attribute stamping failed", exc_info=True)
        super().on_start(span, parent_context)

    def on_end(self, span: ReadableSpan) -> None:
        try:
            keep = bool(self._should_export(span))
        except Exception:
            # SPEC.md §4.3: a raising predicate drops the span, never propagates.
            logger.warning("atlan_ai: should_export_span raised; dropping span", exc_info=True)
            return
        if keep:
            super().on_end(span)
