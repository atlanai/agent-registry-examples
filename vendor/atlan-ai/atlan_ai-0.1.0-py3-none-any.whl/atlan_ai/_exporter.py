"""Exporter construction (SPEC.md §2, §3.3).

Atlan mode: stock OTLP/HTTP protobuf exporter, gzip, pointed at
`{base_url}/otel/v1/traces` with auth + workspace headers.

Generic-collector mode: a bare OTLPSpanExporter, which itself honors the
standard OTEL_EXPORTER_OTLP_(TRACES_)ENDPOINT / _HEADERS env chain — the SDK
adds no Atlan headers there.
"""

from __future__ import annotations

from opentelemetry.exporter.otlp.proto.http import Compression
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

from atlan_ai._config import MODE_ATLAN, Config
from atlan_ai._version import __version__


def build_exporter(config: Config) -> OTLPSpanExporter:
    if config.mode == MODE_ATLAN:
        assert config.api_key is not None and config.workspace_id is not None
        return OTLPSpanExporter(
            endpoint=f"{config.base_url}/otel/v1/traces",
            headers={
                "Authorization": f"Bearer {config.api_key}",
                "X-Atlan-Workspace-Id": config.workspace_id,
                "x-atlan-sdk-name": "python",
                "x-atlan-sdk-version": __version__,
            },
            timeout=int(config.timeout_s),
            compression=Compression.Gzip,
        )
    # Generic-collector mode: delegate endpoint/headers/protocol to OTLP env vars.
    return OTLPSpanExporter(timeout=int(config.timeout_s))
