"""Configuration resolution (SPEC.md §3).

Precedence: explicit constructor arguments > ATLAN_* env > standard OTLP env >
defaults. Misconfiguration never raises out of public APIs except the one
spec-mandated fail-fast: a configured Atlan endpoint without a workspace (§2.4).
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from urllib.parse import urlparse

logger = logging.getLogger("atlan_ai")

DEFAULT_BASE_URL = "https://agentgateway.atlan.engineering"
_LOOPBACK_HOSTS = {"localhost", "127.0.0.1", "::1"}

# Modes (SPEC.md §3.3): "atlan" exports to the gateway with Atlan headers;
# "otlp" is generic-collector mode driven purely by OTEL_EXPORTER_OTLP_* env;
# "disabled" is the no-op posture.
MODE_ATLAN = "atlan"
MODE_OTLP = "otlp"
MODE_DISABLED = "disabled"


class AtlanConfigError(ValueError):
    """Raised only for the spec-mandated fail-fast cases (SPEC.md §2.4)."""


@dataclass(frozen=True)
class Config:
    mode: str
    service_name: str | None
    api_key: str | None
    base_url: str
    workspace_id: str | None
    environment: str | None
    tracing_enabled: bool
    trace_content: bool
    sample_rate: float
    flush_at: int
    flush_interval_s: float
    timeout_s: float
    max_payload_bytes: int
    debug: bool


def _env_str(name: str) -> str | None:
    value = os.environ.get(name)
    return value if value else None


def _env_bool(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None or value == "":
        return default
    return value.strip().lower() in ("true", "1", "yes")


def _env_float(name: str, default: float) -> float:
    value = os.environ.get(name)
    if value is None or value == "":
        return default
    try:
        return float(value)
    except ValueError:
        logger.warning("atlan_ai: ignoring non-numeric %s=%r", name, value)
        return default


def _env_int(name: str, default: int) -> int:
    value = os.environ.get(name)
    if value is None or value == "":
        return default
    try:
        return int(value)
    except ValueError:
        logger.warning("atlan_ai: ignoring non-integer %s=%r", name, value)
        return default


def _otlp_env_endpoint_configured() -> bool:
    return bool(
        _env_str("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT") or _env_str("OTEL_EXPORTER_OTLP_ENDPOINT")
    )


def _validate_base_url(base_url: str) -> bool:
    parsed = urlparse(base_url)
    if parsed.scheme == "https":
        return True
    return parsed.scheme == "http" and parsed.hostname in _LOOPBACK_HOSTS


def resolve_config(
    *,
    service_name: str | None = None,
    api_key: str | None = None,
    base_url: str | None = None,
    workspace_id: str | None = None,
    environment: str | None = None,
    tracing_enabled: bool | None = None,
    trace_content: bool | None = None,
    sample_rate: float | None = None,
) -> Config:
    """Resolve configuration; returns a Config whose mode may be MODE_DISABLED.

    Raises AtlanConfigError only for a configured Atlan endpoint with no
    workspace (SPEC.md §2.4).
    """
    api_key = api_key or _env_str("ATLAN_API_KEY")
    base_url = (base_url or _env_str("ATLAN_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
    workspace_id = workspace_id or _env_str("ATLAN_WORKSPACE_ID")
    environment = environment or _env_str("ATLAN_ENVIRONMENT")
    enabled = tracing_enabled if tracing_enabled is not None else _env_bool("ATLAN_TRACING", True)
    content = trace_content if trace_content is not None else _env_bool("ATLAN_TRACE_CONTENT", True)

    rate = sample_rate if sample_rate is not None else _env_float("ATLAN_SAMPLE_RATE", 1.0)
    if not 0.0 <= rate <= 1.0:
        logger.warning("atlan_ai: sample_rate %r outside [0, 1]; using 1.0", rate)
        rate = 1.0

    mode = MODE_DISABLED
    if enabled:
        if api_key:
            mode = MODE_ATLAN
        elif _otlp_env_endpoint_configured():
            mode = MODE_OTLP
        else:
            logger.warning(
                "atlan_ai: tracing disabled — no ATLAN_API_KEY and no "
                "OTEL_EXPORTER_OTLP_*_ENDPOINT configured"
            )

    if mode == MODE_ATLAN and not _validate_base_url(base_url):
        logger.warning(
            "atlan_ai: tracing disabled — base_url %r must be https (http allowed "
            "only for loopback hosts)",
            base_url,
        )
        mode = MODE_DISABLED

    if mode != MODE_DISABLED and not service_name:
        logger.warning(
            "atlan_ai: tracing disabled — service_name is required, e.g. "
            'atlan_ai.init(service_name="my-agent")'
        )
        mode = MODE_DISABLED

    # SPEC.md §2.4: the one fail-fast. Never export to the gateway without a
    # workspace — those traces land in workspace "default" and are effectively lost.
    if mode == MODE_ATLAN and not workspace_id:
        raise AtlanConfigError(
            "atlan_ai: a workspace is required when exporting to an Atlan endpoint. "
            "Set ATLAN_WORKSPACE_ID or pass workspace_id= to init()."
        )

    return Config(
        mode=mode,
        service_name=service_name,
        api_key=api_key,
        base_url=base_url,
        workspace_id=workspace_id,
        environment=environment,
        tracing_enabled=enabled,
        trace_content=content,
        sample_rate=rate,
        flush_at=_env_int("ATLAN_FLUSH_AT", 64),
        flush_interval_s=_env_float("ATLAN_FLUSH_INTERVAL", 5.0),
        timeout_s=_env_float("ATLAN_TIMEOUT", 30.0),
        max_payload_bytes=_env_int("ATLAN_MAX_PAYLOAD_BYTES", 1024 * 1024),
        debug=_env_bool("ATLAN_DEBUG", False),
    )
