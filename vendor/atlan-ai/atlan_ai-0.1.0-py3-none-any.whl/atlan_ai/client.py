"""Client, init, and lifecycle (SPEC.md §1, §5, §10).

Provider stance: reuse the globally registered TracerProvider when one exists;
otherwise create one (with the Atlan resource and sampler) and register it. The
SDK then attaches exactly one AtlanSpanProcessor. Third-party OTel
instrumentation flows in purely by sharing the provider.
"""

from __future__ import annotations

import atexit
import contextlib
import hashlib
import logging
import os
import threading
from collections.abc import Callable, Iterator, Mapping
from contextlib import contextmanager
from dataclasses import replace
from typing import Any

from opentelemetry import context as context_api
from opentelemetry import trace
from opentelemetry.context import Context
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import ReadableSpan, TracerProvider
from opentelemetry.sdk.trace.export import SpanExporter
from opentelemetry.sdk.trace.id_generator import RandomIdGenerator
from opentelemetry.sdk.trace.sampling import ParentBased, TraceIdRatioBased
from opentelemetry.trace import (
    NonRecordingSpan,
    ProxyTracerProvider,
    SpanContext,
    TraceFlags,
    Tracer,
)

from atlan_ai import _ids
from atlan_ai import _semconv as sc
from atlan_ai._config import MODE_DISABLED, Config, resolve_config
from atlan_ai._exporter import build_exporter
from atlan_ai._masking import MaskFunction, MaskingSpanExporter, MaskOtelSpansFunction
from atlan_ai._processor import AtlanSpanProcessor
from atlan_ai._span_filter import ATLAN_SDK_SCOPE
from atlan_ai._spans import ROOT_SPAN_CONTEXT_KEY, AtlanSpan, noop_span
from atlan_ai._version import __version__

logger = logging.getLogger("atlan_ai")

_registry_lock = threading.Lock()
_clients: dict[str, AtlanAI] = {}
_default_key: str | None = None


def _client_key(api_key: str | None) -> str:
    return hashlib.sha256((api_key or "::anon::").encode("utf-8")).hexdigest()[:16]


def _after_fork_in_child() -> None:
    # A forked child may inherit a lock held mid-acquire by a parent thread
    # (SPEC.md §10.4). The BatchSpanProcessor handles its own worker restart.
    global _registry_lock
    _registry_lock = threading.Lock()


if hasattr(os, "register_at_fork"):  # pragma: no branch
    os.register_at_fork(after_in_child=_after_fork_in_child)


def _hex_to_int(value: object, expected_len: int) -> int | None:
    text = str(value)
    if len(text) != expected_len:
        return None
    try:
        parsed = int(text, 16)
    except ValueError:
        return None
    return parsed if parsed != 0 else None


def _remote_parent_context(
    trace_context: Mapping[str, str] | None,
) -> tuple[Context | None, bool]:
    """SPEC.md §7.3: build a non-recording remote parent from trace_context.

    Returns (context, as_root). With no parent_span_id, a synthetic parent span
    ID pins the trace ID and the created span is marked `atlan.internal.as_root`.
    Invalid IDs are ignored with a warning — never raised.
    """
    if not trace_context:
        return None, False
    trace_id = _hex_to_int(trace_context.get("trace_id"), 32)
    if trace_id is None:
        logger.warning(
            "atlan_ai: ignoring trace_context with invalid trace_id %r",
            trace_context.get("trace_id"),
        )
        return None, False
    parent_raw = trace_context.get("parent_span_id")
    if parent_raw is not None:
        span_id = _hex_to_int(parent_raw, 16)
        if span_id is None:
            logger.warning(
                "atlan_ai: ignoring trace_context with invalid parent_span_id %r", parent_raw
            )
            return None, False
        as_root = False
        is_remote = True
    else:
        span_id = RandomIdGenerator().generate_span_id()
        as_root = True
        is_remote = False
    span_context = SpanContext(
        trace_id=trace_id, span_id=span_id, is_remote=is_remote, trace_flags=TraceFlags(0x01)
    )
    return trace.set_span_in_context(NonRecordingSpan(span_context)), as_root


def _build_resource(config: Config) -> Resource:
    attributes: dict[str, str | bool] = {
        sc.SERVICE_NAME: config.service_name or "",
        sc.ATLAN_SDK_SCHEMA_VERSION: sc.SCHEMA_VERSION,
        sc.ATLAN_SDK_LANGUAGE: "python",
        sc.ATLAN_SDK_VERSION: __version__,
        sc.ATLAN_CONSENT_STORE_CONTENT: config.trace_content,
    }
    if config.environment:
        attributes[sc.ATLAN_ENVIRONMENT] = config.environment
    return Resource.create(attributes)


class AtlanAI:
    """One tracing pipeline. Construct via :func:`init`, retrieve via
    :func:`get_client`. Safe to use when disabled: every method is a no-op."""

    def __init__(
        self,
        config: Config,
        *,
        tracer_provider: TracerProvider | None = None,
        span_exporter: SpanExporter | None = None,
        should_export_span: Callable[[ReadableSpan], bool] | None = None,
        mask: MaskFunction | None = None,
        mask_otel_spans: MaskOtelSpansFunction | None = None,
    ) -> None:
        self.config = config
        self._mask = mask
        self._processor: AtlanSpanProcessor | None = None
        self._provider: TracerProvider | None = None
        self._owns_provider = False
        self._shutdown_done = False

        if config.mode == MODE_DISABLED:
            return

        provider: TracerProvider
        if tracer_provider is not None:
            provider = tracer_provider
        else:
            current = trace.get_tracer_provider()
            if isinstance(current, ProxyTracerProvider):
                sampler = (
                    ParentBased(TraceIdRatioBased(config.sample_rate))
                    if config.sample_rate < 1.0
                    else None
                )
                if sampler is not None:
                    provider = TracerProvider(resource=_build_resource(config), sampler=sampler)
                else:
                    provider = TracerProvider(resource=_build_resource(config))
                trace.set_tracer_provider(provider)
                self._owns_provider = True
            elif isinstance(current, TracerProvider):
                # SPEC.md §5.3: reuse, never mutate the existing provider's resource.
                logger.debug(
                    "atlan_ai: reusing existing global TracerProvider; Atlan resource "
                    "attributes and sampler do not apply"
                )
                provider = current
            else:
                logger.warning(
                    "atlan_ai: tracing disabled — the registered global tracer provider "
                    "(%s) does not support span processors",
                    type(current).__name__,
                )
                self.config = replace(config, mode=MODE_DISABLED)
                return

        exporter = span_exporter or build_exporter(self.config)
        if mask_otel_spans is not None:
            exporter = MaskingSpanExporter(exporter, mask_otel_spans)
        flush_at = 1 if config.debug else config.flush_at
        flush_interval_s = 0.1 if config.debug else config.flush_interval_s
        self._processor = AtlanSpanProcessor(
            exporter,
            flush_at=flush_at,
            flush_interval_s=flush_interval_s,
            timeout_s=config.timeout_s,
            should_export_span=should_export_span,
            trace_content=config.trace_content,
            mask=mask,
        )
        provider.add_span_processor(self._processor)
        self._provider = provider
        atexit.register(self._atexit)

    @property
    def is_enabled(self) -> bool:
        return self._processor is not None

    def get_tracer(self) -> Tracer:
        provider = self._provider if self._provider is not None else trace.get_tracer_provider()
        return provider.get_tracer(ATLAN_SDK_SCOPE, __version__)

    def start_span(
        self,
        name: str,
        *,
        as_type: str = "task",
        trace_context: Mapping[str, str] | None = None,
        parent: AtlanSpan | None = None,
        **fields: Any,
    ) -> AtlanSpan:
        """Create a span WITHOUT making it current; caller must call .end().

        ``parent`` explicitly parents the span under another AtlanSpan (used by
        framework integrations that track their own run trees); it takes
        precedence over ``trace_context``.
        """
        if self._processor is None:
            return noop_span(self.config)
        if parent is not None:
            context: Context | None = trace.set_span_in_context(parent.otel_span)
            as_root = False
        else:
            context, as_root = _remote_parent_context(trace_context)
        otel_span = self.get_tracer().start_span(name, context=context)
        span = AtlanSpan(otel_span, self.config, mask=self._mask)
        span._initialize(as_type, as_root)
        if fields:
            span.update(**fields)
        return span

    @contextmanager
    def start_as_current_span(
        self,
        name: str,
        *,
        as_type: str = "task",
        trace_context: Mapping[str, str] | None = None,
        end_on_exit: bool = True,
        **fields: Any,
    ) -> Iterator[AtlanSpan]:
        """Create a span, make it current for the block, and end it on exit.

        Exceptions are recorded, mark the span ERROR, and re-raise (SPEC.md §9.2).
        """
        if self._processor is None:
            yield noop_span(self.config)
            return
        context, as_root = _remote_parent_context(trace_context)
        with self.get_tracer().start_as_current_span(
            name,
            context=context,
            end_on_exit=end_on_exit,
            record_exception=False,
            set_status_on_exception=False,
        ) as otel_span:
            span = AtlanSpan(otel_span, self.config, mask=self._mask)
            span._initialize(as_type, as_root)
            if fields:
                span.update(**fields)
            # Register the trace's root span so score_trace() can find it.
            root_token = None
            existing_root = context_api.get_value(ROOT_SPAN_CONTEXT_KEY)
            if not (
                isinstance(existing_root, AtlanSpan) and existing_root.trace_id == span.trace_id
            ):
                root_token = context_api.attach(context_api.set_value(ROOT_SPAN_CONTEXT_KEY, span))
            try:
                yield span
            except BaseException as error:
                span.record_failure(error)
                raise
            finally:
                if root_token is not None:
                    with contextlib.suppress(Exception):
                        context_api.detach(root_token)

    @staticmethod
    def create_trace_id(seed: str | None = None) -> str:
        return _ids.create_trace_id(seed)

    @staticmethod
    def create_span_id(seed: str | None = None) -> str:
        return _ids.create_span_id(seed)

    def flush(self) -> None:
        if self._processor is not None:
            self._processor.force_flush(int(self.config.timeout_s * 1000))

    def shutdown(self) -> None:
        if self._shutdown_done or self._processor is None:
            return
        self._shutdown_done = True
        try:
            if self._owns_provider and isinstance(self._provider, TracerProvider):
                self._provider.shutdown()
            else:
                self._processor.shutdown()
        except Exception:  # SPEC.md §10.5 — never break the host app on teardown
            logger.debug("atlan_ai: shutdown failed", exc_info=True)

    def _atexit(self) -> None:
        with contextlib.suppress(Exception):
            self.shutdown()


def init(
    *,
    service_name: str | None = None,
    api_key: str | None = None,
    base_url: str | None = None,
    workspace_id: str | None = None,
    environment: str | None = None,
    tracing_enabled: bool | None = None,
    trace_content: bool | None = None,
    sample_rate: float | None = None,
    tracer_provider: TracerProvider | None = None,
    span_exporter: SpanExporter | None = None,
    should_export_span: Callable[[ReadableSpan], bool] | None = None,
    mask: MaskFunction | None = None,
    mask_otel_spans: MaskOtelSpansFunction | None = None,
) -> AtlanAI:
    """Initialize the SDK. Idempotent per API key (SPEC.md §10.2).

    Raises AtlanConfigError only when an Atlan endpoint is configured without a
    workspace (SPEC.md §2.4). All other misconfiguration logs a warning and
    returns a disabled, no-op client.
    """
    config = resolve_config(
        service_name=service_name,
        api_key=api_key,
        base_url=base_url,
        workspace_id=workspace_id,
        environment=environment,
        tracing_enabled=tracing_enabled,
        trace_content=trace_content,
        sample_rate=sample_rate,
    )
    key = _client_key(config.api_key)
    global _default_key
    with _registry_lock:
        existing = _clients.get(key)
        if existing is not None:
            return existing
        client = AtlanAI(
            config,
            tracer_provider=tracer_provider,
            span_exporter=span_exporter,
            should_export_span=should_export_span,
            mask=mask,
            mask_otel_spans=mask_otel_spans,
        )
        _clients[key] = client
        _default_key = key
        return client


_DISABLED_CONFIG = Config(
    mode=MODE_DISABLED,
    service_name=None,
    api_key=None,
    base_url="",
    workspace_id=None,
    environment=None,
    tracing_enabled=False,
    trace_content=True,
    sample_rate=1.0,
    flush_at=64,
    flush_interval_s=5.0,
    timeout_s=30.0,
    max_payload_bytes=1024 * 1024,
    debug=False,
)


def get_client() -> AtlanAI:
    """Return the most recently initialized client, or a disabled no-op client."""
    with _registry_lock:
        if _default_key is not None and _default_key in _clients:
            return _clients[_default_key]
    return AtlanAI(_DISABLED_CONFIG)


def _reset_for_tests() -> None:
    global _default_key
    with _registry_lock:
        _clients.clear()
        _default_key = None
