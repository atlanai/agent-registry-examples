"""The @observe decorator (SPEC.md §9.2, plan Phase 2-4).

Supports plain functions, coroutines, sync generators, and async generators.
Generator spans stay open across yields; each resumption runs with the span
active in context without leaking it into the caller between yields; output is
the accumulated list of yielded items. When the SDK is uninitialized or
disabled, the wrapped function runs unchanged.

Per-call magic kwargs (stripped before invoking the function):
``atlan_trace_id`` and ``atlan_parent_span_id`` route the span into an existing
trace via SPEC.md §7.3.
"""

from __future__ import annotations

import functools
import inspect
import logging
from collections.abc import AsyncIterator, Callable, Iterator
from typing import Any, TypeVar, overload

from opentelemetry import context as context_api
from opentelemetry import trace

from atlan_ai.client import get_client

logger = logging.getLogger("atlan_ai")

F = TypeVar("F", bound=Callable[..., Any])

_TRACE_ID_KWARG = "atlan_trace_id"
_PARENT_SPAN_ID_KWARG = "atlan_parent_span_id"


def _extract_trace_context(kwargs: dict[str, Any]) -> dict[str, str] | None:
    trace_id = kwargs.pop(_TRACE_ID_KWARG, None)
    parent_span_id = kwargs.pop(_PARENT_SPAN_ID_KWARG, None)
    if trace_id is None:
        if parent_span_id is not None:
            logger.warning(
                "atlan_ai: %s given without %s; ignoring", _PARENT_SPAN_ID_KWARG, _TRACE_ID_KWARG
            )
        return None
    trace_context = {"trace_id": str(trace_id)}
    if parent_span_id is not None:
        trace_context["parent_span_id"] = str(parent_span_id)
    return trace_context


def _capture_input(
    fn: Callable[..., Any], args: tuple[Any, ...], kwargs: dict[str, Any]
) -> dict[str, Any]:
    shown = list(args)
    try:
        params = list(inspect.signature(fn).parameters)
        if params and params[0] in ("self", "cls") and shown:
            shown = shown[1:]
    except (TypeError, ValueError):
        pass
    return {"args": shown, "kwargs": dict(kwargs)}


@overload
def observe(func: F) -> F: ...


@overload
def observe(
    *,
    name: str | None = None,
    as_type: str = "task",
    capture_input: bool = True,
    capture_output: bool = True,
) -> Callable[[F], F]: ...


def observe(
    func: F | None = None,
    *,
    name: str | None = None,
    as_type: str = "task",
    capture_input: bool = True,
    capture_output: bool = True,
) -> F | Callable[[F], F]:
    """Trace a function as an agent-sdk.v1 observation. Usable bare or called."""

    def decorator(fn: F) -> F:
        span_name: str = name if name is not None else str(getattr(fn, "__name__", "observed"))

        if inspect.isasyncgenfunction(fn):
            wrapper: Callable[..., Any] = _wrap_async_gen(
                fn, span_name, as_type, capture_input, capture_output
            )
        elif inspect.iscoroutinefunction(fn):
            wrapper = _wrap_async(fn, span_name, as_type, capture_input, capture_output)
        elif inspect.isgeneratorfunction(fn):
            wrapper = _wrap_sync_gen(fn, span_name, as_type, capture_input, capture_output)
        else:
            wrapper = _wrap_sync(fn, span_name, as_type, capture_input, capture_output)
        return wrapper  # type: ignore[return-value]

    if func is not None:
        return decorator(func)
    return decorator


def _strip_magic_kwargs(kwargs: dict[str, Any]) -> None:
    kwargs.pop(_TRACE_ID_KWARG, None)
    kwargs.pop(_PARENT_SPAN_ID_KWARG, None)


def _wrap_sync(
    fn: Callable[..., Any],
    span_name: str,
    as_type: str,
    capture_input: bool,
    capture_output: bool,
) -> Callable[..., Any]:
    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        client = get_client()
        if not client.is_enabled:
            _strip_magic_kwargs(kwargs)
            return fn(*args, **kwargs)
        trace_context = _extract_trace_context(kwargs)
        with client.start_as_current_span(
            span_name, as_type=as_type, trace_context=trace_context
        ) as span:
            if capture_input:
                span.update(input=_capture_input(fn, args, kwargs))
            result = fn(*args, **kwargs)
            if capture_output:
                span.update(output=result)
            return result

    return wrapper


def _wrap_async(
    fn: Callable[..., Any],
    span_name: str,
    as_type: str,
    capture_input: bool,
    capture_output: bool,
) -> Callable[..., Any]:
    @functools.wraps(fn)
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        client = get_client()
        if not client.is_enabled:
            _strip_magic_kwargs(kwargs)
            return await fn(*args, **kwargs)
        trace_context = _extract_trace_context(kwargs)
        with client.start_as_current_span(
            span_name, as_type=as_type, trace_context=trace_context
        ) as span:
            if capture_input:
                span.update(input=_capture_input(fn, args, kwargs))
            result = await fn(*args, **kwargs)
            if capture_output:
                span.update(output=result)
            return result

    return wrapper


def _wrap_sync_gen(
    fn: Callable[..., Any],
    span_name: str,
    as_type: str,
    capture_input: bool,
    capture_output: bool,
) -> Callable[..., Any]:
    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Iterator[Any]:
        client = get_client()
        if not client.is_enabled:
            _strip_magic_kwargs(kwargs)
            yield from fn(*args, **kwargs)
            return
        trace_context = _extract_trace_context(kwargs)
        span = client.start_span(span_name, as_type=as_type, trace_context=trace_context)
        span_context = trace.set_span_in_context(span.otel_span)
        if capture_input:
            span.update(input=_capture_input(fn, args, kwargs))
        items: list[Any] = []
        try:
            generator = fn(*args, **kwargs)
            while True:
                token = context_api.attach(span_context)
                try:
                    try:
                        item = next(generator)
                    except StopIteration:
                        break
                finally:
                    context_api.detach(token)
                items.append(item)
                yield item
            if capture_output:
                span.update(output=items)
        except GeneratorExit:
            # Early close by the consumer is normal control flow, not an error.
            raise
        except BaseException as error:
            span.record_failure(error)
            raise
        finally:
            span.end()

    return wrapper


def _wrap_async_gen(
    fn: Callable[..., Any],
    span_name: str,
    as_type: str,
    capture_input: bool,
    capture_output: bool,
) -> Callable[..., Any]:
    @functools.wraps(fn)
    async def wrapper(*args: Any, **kwargs: Any) -> AsyncIterator[Any]:
        client = get_client()
        if not client.is_enabled:
            _strip_magic_kwargs(kwargs)
            async for item in fn(*args, **kwargs):
                yield item
            return
        trace_context = _extract_trace_context(kwargs)
        span = client.start_span(span_name, as_type=as_type, trace_context=trace_context)
        span_context = trace.set_span_in_context(span.otel_span)
        if capture_input:
            span.update(input=_capture_input(fn, args, kwargs))
        items: list[Any] = []
        try:
            generator = fn(*args, **kwargs)
            while True:
                token = context_api.attach(span_context)
                try:
                    try:
                        item = await generator.__anext__()
                    except StopAsyncIteration:
                        break
                finally:
                    context_api.detach(token)
                items.append(item)
                yield item
            if capture_output:
                span.update(output=items)
        except GeneratorExit:
            raise
        except BaseException as error:
            span.record_failure(error)
            raise
        finally:
            span.end()

    return wrapper
