"""LangChain / LangGraph callback handler for the Atlan SDK (plan Phase 5).

Usage::

    from atlan_ai.langchain import CallbackHandler
    graph.invoke(inputs, config={"callbacks": [CallbackHandler()]})

Maps LangChain's run tree (run_id / parent_run_id) onto agent-sdk.v1 spans:
chains → ``task``, LLM/chat-model runs → ``llm``, tools → ``tool``. Each run's
span is attached to OTel context for its duration so provider auto-
instrumentation nests correctly — and LLM runs set the OpenLLMetry suppression
key so provider instrumentors do not double-span underneath.

LangGraph specifics: control-flow exceptions (``GraphBubbleUp`` interrupts) end
runs without marking them errored, and an interrupt→resume pair on the same
``thread_id`` continues the SAME trace (the interrupted root's trace/span IDs
are kept in a bounded store and consumed by the next explicit
``Command(resume=...)`` root run).

Trace-level association is read from LangChain metadata: ``atlan_session_id``,
``atlan_user_id``, ``atlan_tags``, ``atlan_trace_name`` (and, for migrations,
the ``langfuse_*`` equivalents when ``compat_langfuse_keys`` is enabled).

This module is an original implementation. Where interoperability requires
matching ecosystem conventions it does so deliberately: it reads the community
``langfuse_*`` metadata keys (opt out via ``compat_langfuse_keys``), sets
OpenLLMetry's suppression context key, and normalizes the token-usage field
names each provider documents in its public API.
"""

from __future__ import annotations

import datetime as _dt
import logging
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any
from uuid import UUID

from opentelemetry import context as context_api
from opentelemetry import trace

from atlan_ai._propagation import propagate_attributes
from atlan_ai._semconv import ATLAN_COMPLETION_START_TIME
from atlan_ai._spans import AtlanSpan
from atlan_ai.client import get_client

try:
    from langchain_core.callbacks.base import BaseCallbackHandler
    from langchain_core.outputs import LLMResult
except ImportError as error:  # pragma: no cover
    raise ModuleNotFoundError(
        "atlan_ai.langchain requires langchain-core: pip install langchain-core"
    ) from error

logger = logging.getLogger("atlan_ai")

# OpenLLMetry's context key: set while an LLM span is open so provider
# instrumentors (opentelemetry-instrumentation-anthropic/openai/...) go quiet.
SUPPRESS_LANGUAGE_MODEL_INSTRUMENTATION_KEY = "suppress_language_model_instrumentation"

MAX_PENDING_RESUME_TRACE_CONTEXTS = 1024

_NOISE_METADATA_RE = re.compile(r"^(ls_|lc_|langgraph_|__pregel_|checkpoint_)")

_ATLAN_TRACE_KEYS = {
    "atlan_session_id": "session_id",
    "atlan_user_id": "user_id",
    "atlan_tags": "tags",
    "atlan_trace_name": "trace_name",
}
_LANGFUSE_TRACE_KEYS = {
    "langfuse_session_id": "session_id",
    "langfuse_user_id": "user_id",
    "langfuse_tags": "tags",
    "langfuse_trace_name": "trace_name",
}

# LangGraph control flow: detected by class when langgraph is importable, by
# MRO class name otherwise (keeps the handler testable without langgraph).
_CONTROL_FLOW_CLASS_NAMES = {"GraphBubbleUp", "GraphInterrupt", "NodeInterrupt", "ParentCommand"}
try:  # pragma: no cover - depends on the host app's environment
    from langgraph.errors import GraphBubbleUp as _GraphBubbleUp
except ImportError:
    _GraphBubbleUp = None


def _is_control_flow_exception(error: BaseException) -> bool:
    if _GraphBubbleUp is not None and isinstance(error, _GraphBubbleUp):
        return True
    return any(cls.__name__ in _CONTROL_FLOW_CLASS_NAMES for cls in type(error).__mro__)


def _is_langgraph_resume(inputs: object) -> bool:
    return type(inputs).__name__ == "Command" and getattr(inputs, "resume", None) is not None


# Token-usage field spellings, per provider public API documentation, mapped
# onto our canonical usage keys. First present integer source wins per target.
#   - LangChain standard UsageMetadata and the Anthropic Messages API both use
#     input_tokens/output_tokens (+ Anthropic cache_read/cache_creation).
#   - OpenAI chat completions: prompt_tokens/completion_tokens/total_tokens.
#   - Gemini/Vertex usageMetadata: prompt_token_count/candidates_token_count/
#     total_token_count (snake_cased by the langchain-google packages).
#   - Bedrock invocation metrics: inputTokenCount/outputTokenCount/
#     totalTokenCount.
#   - IBM watsonx.ai generation metadata: input_token_count/
#     generated_token_count.
_USAGE_SOURCE_KEYS: dict[str, tuple[str, ...]] = {
    "input_tokens": (
        "input_tokens",
        "prompt_tokens",
        "prompt_token_count",
        "inputTokenCount",
        "input_token_count",
    ),
    "output_tokens": (
        "output_tokens",
        "completion_tokens",
        "candidates_token_count",
        "outputTokenCount",
        "generated_token_count",
    ),
    "total_tokens": ("total_tokens", "total_token_count", "totalTokenCount"),
    "cache_read_input_tokens": ("cache_read_input_tokens",),
    "cache_creation_input_tokens": ("cache_creation_input_tokens",),
}

_MODEL_KEYS = ("model_name", "model", "model_id", "deployment_name", "azure_deployment")


def normalize_usage(raw: Mapping[str, Any]) -> dict[str, int]:
    """Translate vendor usage spellings into our canonical usage keys."""
    usage: dict[str, int] = {}
    for target_key, source_keys in _USAGE_SOURCE_KEYS.items():
        for source_key in source_keys:
            value = raw.get(source_key)
            if isinstance(value, list):
                # Some providers report streamed responses as per-chunk count
                # lists; the request total is their sum.
                value = sum(item for item in value if isinstance(item, int))
            if isinstance(value, bool) or not isinstance(value, int):
                continue
            usage[target_key] = value
            break
    # langchain-standard usage_metadata sub-details
    input_details = raw.get("input_token_details")
    if isinstance(input_details, Mapping):
        for detail_key, target_key in (
            ("cache_read", "cache_read_input_tokens"),
            ("cache_creation", "cache_creation_input_tokens"),
        ):
            value = input_details.get(detail_key)
            if isinstance(value, int) and not isinstance(value, bool):
                usage.setdefault(target_key, value)
    # OpenAI / LiteLLM prompt_tokens_details
    prompt_details = raw.get("prompt_tokens_details")
    if isinstance(prompt_details, Mapping):
        cached = prompt_details.get("cached_tokens")
        if isinstance(cached, int) and not isinstance(cached, bool):
            usage.setdefault("cache_read_input_tokens", cached)
    return usage


def _extract_usage(response: LLMResult) -> dict[str, int]:
    for generations in response.generations:
        for generation in generations:
            message = getattr(generation, "message", None)
            usage_metadata = getattr(message, "usage_metadata", None)
            if isinstance(usage_metadata, Mapping) and usage_metadata:
                return normalize_usage(usage_metadata)
    llm_output = response.llm_output or {}
    for key in ("token_usage", "usage"):
        raw = llm_output.get(key)
        if hasattr(raw, "__dict__") and not isinstance(raw, Mapping):
            raw = vars(raw)
        if isinstance(raw, Mapping) and raw:
            return normalize_usage(raw)
    return {}


def _extract_model(serialized: Mapping[str, Any] | None, kwargs: Mapping[str, Any]) -> str | None:
    invocation_params = kwargs.get("invocation_params")
    if isinstance(invocation_params, Mapping):
        for key in _MODEL_KEYS:
            value = invocation_params.get(key)
            if isinstance(value, str) and value:
                return value
    if isinstance(serialized, Mapping):
        serialized_kwargs = serialized.get("kwargs")
        if isinstance(serialized_kwargs, Mapping):
            for key in _MODEL_KEYS:
                value = serialized_kwargs.get(key)
                if isinstance(value, str) and value:
                    return value
    return None


def _run_name(serialized: Mapping[str, Any] | None, kwargs: Mapping[str, Any]) -> str:
    name = kwargs.get("name")
    if isinstance(name, str) and name:
        return name
    if isinstance(serialized, Mapping):
        serialized_name = serialized.get("name")
        if isinstance(serialized_name, str) and serialized_name:
            return serialized_name
        id_path = serialized.get("id")
        if isinstance(id_path, Sequence) and id_path and isinstance(id_path[-1], str):
            return id_path[-1]
    return "langchain-run"


def _messages_to_plain(messages: Sequence[Any]) -> list[dict[str, Any]]:
    plain: list[dict[str, Any]] = []
    for message in messages:
        role = getattr(message, "type", None) or type(message).__name__
        content = getattr(message, "content", message)
        plain.append({"role": str(role), "parts": [{"type": "text", "content": content}]})
    return plain


def _clean_metadata(metadata: Mapping[str, Any] | None) -> dict[str, Any]:
    if not metadata:
        return {}
    return {
        key: value
        for key, value in metadata.items()
        if not _NOISE_METADATA_RE.match(key)
        and key not in _ATLAN_TRACE_KEYS
        and key not in _LANGFUSE_TRACE_KEYS
    }


@dataclass
class _RunState:
    parent_run_id: UUID | None
    root_run_id: UUID


@dataclass
class _RootState:
    run_ids: set[UUID] = field(default_factory=set)
    resume_key: str | None = None
    propagation_cm: Any = None


class _ResumeContexts:
    """Pending interrupt trace-contexts keyed by thread id.

    Bounded so abandoned interrupts cannot grow memory forever: when the cap is
    exceeded the oldest entry is evicted (insertion order; re-remembering a key
    refreshes its position).
    """

    def __init__(self, capacity: int) -> None:
        self._capacity = capacity
        self._contexts: dict[str, dict[str, str]] = {}

    def remember(self, thread_key: str, trace_context: dict[str, str]) -> None:
        self._contexts.pop(thread_key, None)
        self._contexts[thread_key] = trace_context
        while len(self._contexts) > self._capacity:
            del self._contexts[next(iter(self._contexts))]

    def claim(self, thread_key: str) -> dict[str, str] | None:
        return self._contexts.pop(thread_key, None)

    def __len__(self) -> int:
        return len(self._contexts)


class CallbackHandler(BaseCallbackHandler):
    """Attach to LangChain/LangGraph invocations via ``config={"callbacks": [...]}``."""

    raise_error = False

    def __init__(self, *, compat_langfuse_keys: bool = True) -> None:
        super().__init__()
        self._compat_langfuse_keys = compat_langfuse_keys
        self._spans: dict[UUID, AtlanSpan] = {}
        self._context_tokens: dict[UUID, object] = {}
        self._run_states: dict[UUID, _RunState] = {}
        self._root_states: dict[UUID, _RootState] = {}
        self._completion_start_marked: set[UUID] = set()
        self._pending_resume = _ResumeContexts(MAX_PENDING_RESUME_TRACE_CONTEXTS)

    # ------------------------------------------------------------------ core

    def _track_run(
        self, run_id: UUID, parent_run_id: UUID | None, metadata: Mapping[str, Any] | None
    ) -> None:
        if parent_run_id is None:
            root_run_id = run_id
            thread_id = metadata.get("thread_id") if metadata else None
            self._root_states[run_id] = _RootState(
                run_ids={run_id},
                resume_key=str(thread_id) if thread_id is not None else None,
            )
        else:
            parent_state = self._run_states.get(parent_run_id)
            root_run_id = parent_state.root_run_id if parent_state else parent_run_id
            self._root_states.setdefault(root_run_id, _RootState()).run_ids.add(run_id)
        self._run_states[run_id] = _RunState(parent_run_id=parent_run_id, root_run_id=root_run_id)

    def _trace_attributes(self, metadata: Mapping[str, Any] | None) -> dict[str, Any]:
        if not metadata:
            return {}
        found: dict[str, Any] = {}
        for key, target in _ATLAN_TRACE_KEYS.items():
            if key in metadata:
                found[target] = metadata[key]
        if self._compat_langfuse_keys:
            for key, target in _LANGFUSE_TRACE_KEYS.items():
                if target not in found and key in metadata:
                    found[target] = metadata[key]
        return found

    def _resume_trace_context(
        self, inputs: object, metadata: Mapping[str, Any] | None
    ) -> dict[str, str] | None:
        # Only an explicit LangGraph Command(resume=...) with no active parent
        # span consumes the pending interrupt linkage; an unrelated root run
        # on the same thread is not a resume and must start a fresh trace.
        if trace.get_current_span().get_span_context().is_valid:
            return None
        if not _is_langgraph_resume(inputs):
            return None
        thread_id = metadata.get("thread_id") if metadata else None
        if thread_id is None:
            return None
        return self._pending_resume.claim(str(thread_id))

    def _start_run_span(
        self,
        *,
        run_id: UUID,
        parent_run_id: UUID | None,
        name: str,
        as_type: str,
        run_metadata: Mapping[str, Any] | None,
        suppress_llm: bool = False,
        trace_context: dict[str, str] | None = None,
        **fields: Any,
    ) -> AtlanSpan | None:
        client = get_client()
        if not client.is_enabled:
            return None
        self._track_run(run_id, parent_run_id, run_metadata)

        if parent_run_id is None:
            trace_kwargs = self._trace_attributes(run_metadata)
            if trace_kwargs:
                propagation_cm = propagate_attributes(**trace_kwargs)
                propagation_cm.__enter__()
                self._root_states[run_id].propagation_cm = propagation_cm

        parent_span = self._spans.get(parent_run_id) if parent_run_id else None
        span = client.start_span(
            name, as_type=as_type, parent=parent_span, trace_context=trace_context, **fields
        )
        self._spans[run_id] = span

        span_context = trace.set_span_in_context(span.otel_span)
        if suppress_llm:
            span_context = context_api.set_value(
                SUPPRESS_LANGUAGE_MODEL_INSTRUMENTATION_KEY, True, span_context
            )
        self._context_tokens[run_id] = context_api.attach(span_context)
        return span

    def _end_run_span(
        self,
        run_id: UUID,
        *,
        error: BaseException | None = None,
        **fields: Any,
    ) -> None:
        token = self._context_tokens.pop(run_id, None)
        if token is not None:
            try:
                context_api.detach(token)  # type: ignore[arg-type]
            except Exception:  # cross-task detach in async frameworks
                logger.debug("atlan_ai: langchain context detach failed", exc_info=True)

        span = self._spans.pop(run_id, None)
        self._completion_start_marked.discard(run_id)
        if span is None:
            self._cleanup_run(run_id, error)
            return
        try:
            if fields:
                span.update(**fields)
            if error is not None:
                if _is_control_flow_exception(error):
                    # LangGraph interrupts/handoffs are expected control flow.
                    span.update(level="DEFAULT", status_message=str(error) or type(error).__name__)
                else:
                    span.record_failure(error)
        finally:
            span.end()
            self._cleanup_run(run_id, error, span)

    def _cleanup_run(
        self, run_id: UUID, error: BaseException | None, span: AtlanSpan | None = None
    ) -> None:
        run_state = self._run_states.pop(run_id, None)
        if run_state is None:
            return
        if run_state.root_run_id != run_id:
            root_state = self._root_states.get(run_state.root_run_id)
            if root_state is not None:
                root_state.run_ids.discard(run_id)
            return
        # Root run finished: persist interrupt linkage, exit propagation scope,
        # and drop the whole tree's bookkeeping.
        root_state = self._root_states.pop(run_id, None)
        if root_state is None:
            return
        if (
            span is not None
            and error is not None
            and _is_control_flow_exception(error)
            and root_state.resume_key is not None
        ):
            self._pending_resume.remember(
                root_state.resume_key,
                {"trace_id": span.trace_id, "parent_span_id": span.span_id},
            )
        if root_state.propagation_cm is not None:
            try:
                root_state.propagation_cm.__exit__(None, None, None)
            except Exception:
                logger.debug("atlan_ai: propagation scope exit failed", exc_info=True)
        for orphan in root_state.run_ids:
            self._run_states.pop(orphan, None)

    # ---------------------------------------------------------------- chains

    def on_chain_start(
        self,
        serialized: dict[str, Any] | None,
        inputs: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            name = _run_name(serialized, kwargs)
            trace_context = None
            if parent_run_id is None:
                trace_context = self._resume_trace_context(inputs, metadata)
            extra_metadata = _clean_metadata(metadata)
            id_path = serialized.get("id") if isinstance(serialized, Mapping) else None
            if (
                isinstance(id_path, Sequence)
                and any("agent" in str(part).lower() for part in id_path)
            ) or "agent" in name.lower():
                extra_metadata.setdefault("langchain_kind", "agent")
            fields: dict[str, Any] = {"input": inputs}
            if extra_metadata:
                fields["metadata"] = extra_metadata
            self._start_run_span(
                run_id=run_id,
                parent_run_id=parent_run_id,
                name=name,
                as_type="task",
                run_metadata=metadata,
                trace_context=trace_context,
                **fields,
            )
        except Exception:
            logger.debug("atlan_ai: on_chain_start failed", exc_info=True)

    def on_chain_end(self, outputs: Any, *, run_id: UUID, **kwargs: Any) -> None:
        try:
            self._end_run_span(run_id, output=outputs)
        except Exception:
            logger.debug("atlan_ai: on_chain_end failed", exc_info=True)

    def on_chain_error(self, error: BaseException, *, run_id: UUID, **kwargs: Any) -> None:
        try:
            self._end_run_span(run_id, error=error)
        except Exception:
            logger.debug("atlan_ai: on_chain_error failed", exc_info=True)

    # ------------------------------------------------------------------ LLMs

    def _on_model_start(
        self,
        serialized: dict[str, Any] | None,
        model_input: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None,
        metadata: dict[str, Any] | None,
        kwargs: Mapping[str, Any],
    ) -> None:
        model = _extract_model(serialized, kwargs)
        fields: dict[str, Any] = {"input": model_input}
        if model:
            fields["model"] = model
        self._start_run_span(
            run_id=run_id,
            parent_run_id=parent_run_id,
            name=_run_name(serialized, kwargs),
            as_type="llm",
            run_metadata=metadata,
            suppress_llm=True,
            **fields,
        )

    def on_llm_start(
        self,
        serialized: dict[str, Any] | None,
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            self._on_model_start(
                serialized,
                prompts,
                run_id=run_id,
                parent_run_id=parent_run_id,
                metadata=metadata,
                kwargs=kwargs,
            )
        except Exception:
            logger.debug("atlan_ai: on_llm_start failed", exc_info=True)

    def on_chat_model_start(
        self,
        serialized: dict[str, Any] | None,
        messages: list[list[Any]],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            plain = _messages_to_plain(messages[0]) if messages else []
            self._on_model_start(
                serialized,
                plain,
                run_id=run_id,
                parent_run_id=parent_run_id,
                metadata=metadata,
                kwargs=kwargs,
            )
        except Exception:
            logger.debug("atlan_ai: on_chat_model_start failed", exc_info=True)

    def on_llm_new_token(self, token: Any, *, run_id: UUID, **kwargs: Any) -> None:
        try:
            if run_id in self._completion_start_marked:
                return
            span = self._spans.get(run_id)
            if span is None or not span.otel_span.is_recording():
                return
            self._completion_start_marked.add(run_id)
            span.otel_span.set_attribute(
                ATLAN_COMPLETION_START_TIME,
                _dt.datetime.now(_dt.timezone.utc).isoformat(),
            )
        except Exception:
            logger.debug("atlan_ai: on_llm_new_token failed", exc_info=True)

    def on_llm_end(self, response: LLMResult, *, run_id: UUID, **kwargs: Any) -> None:
        try:
            fields: dict[str, Any] = {}
            usage = _extract_usage(response)
            if usage:
                fields["usage"] = usage
            llm_output = response.llm_output or {}
            for key in ("model_name", "model"):
                value = llm_output.get(key)
                if isinstance(value, str) and value:
                    fields["response_model"] = value
                    break
            outputs: list[Any] = []
            for generations in response.generations:
                for generation in generations:
                    message = getattr(generation, "message", None)
                    if message is not None:
                        outputs.extend(_messages_to_plain([message]))
                    else:
                        outputs.append(getattr(generation, "text", None))
            if outputs:
                fields["output"] = outputs
            self._end_run_span(run_id, **fields)
        except Exception:
            logger.debug("atlan_ai: on_llm_end failed", exc_info=True)

    def on_llm_error(self, error: BaseException, *, run_id: UUID, **kwargs: Any) -> None:
        try:
            self._end_run_span(run_id, error=error)
        except Exception:
            logger.debug("atlan_ai: on_llm_error failed", exc_info=True)

    # ----------------------------------------------------------------- tools

    def on_tool_start(
        self,
        serialized: dict[str, Any] | None,
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        inputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            name = _run_name(serialized, kwargs)
            self._start_run_span(
                run_id=run_id,
                parent_run_id=parent_run_id,
                name=name,
                as_type="tool",
                run_metadata=metadata,
                input=inputs if inputs is not None else input_str,
                tool_name=name,
            )
        except Exception:
            logger.debug("atlan_ai: on_tool_start failed", exc_info=True)

    def on_tool_end(self, output: Any, *, run_id: UUID, **kwargs: Any) -> None:
        try:
            self._end_run_span(run_id, output=output)
        except Exception:
            logger.debug("atlan_ai: on_tool_end failed", exc_info=True)

    def on_tool_error(self, error: BaseException, *, run_id: UUID, **kwargs: Any) -> None:
        try:
            self._end_run_span(run_id, error=error)
        except Exception:
            logger.debug("atlan_ai: on_tool_error failed", exc_info=True)

    # ------------------------------------------------------------- retriever

    def on_retriever_start(
        self,
        serialized: dict[str, Any] | None,
        query: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            fields: dict[str, Any] = {
                "input": query,
                "metadata": {"langchain_kind": "retriever"},
            }
            self._start_run_span(
                run_id=run_id,
                parent_run_id=parent_run_id,
                name=_run_name(serialized, kwargs),
                as_type="task",
                run_metadata=metadata,
                **fields,
            )
        except Exception:
            logger.debug("atlan_ai: on_retriever_start failed", exc_info=True)

    def on_retriever_end(self, documents: Sequence[Any], *, run_id: UUID, **kwargs: Any) -> None:
        try:
            output = [getattr(doc, "page_content", doc) for doc in documents]
            self._end_run_span(run_id, output=output)
        except Exception:
            logger.debug("atlan_ai: on_retriever_end failed", exc_info=True)

    def on_retriever_error(self, error: BaseException, *, run_id: UUID, **kwargs: Any) -> None:
        try:
            self._end_run_span(run_id, error=error)
        except Exception:
            logger.debug("atlan_ai: on_retriever_error failed", exc_info=True)

    # ----------------------------------------------------------------- agent

    def on_agent_action(self, action: Any, *, run_id: UUID, **kwargs: Any) -> None:
        try:
            span = self._spans.get(run_id)
            if span is not None:
                span.update(metadata={"langchain_kind": "agent"})
        except Exception:
            logger.debug("atlan_ai: on_agent_action failed", exc_info=True)

    def on_agent_finish(self, finish: Any, *, run_id: UUID, **kwargs: Any) -> None:
        try:
            span = self._spans.get(run_id)
            if span is not None:
                return_values = getattr(finish, "return_values", None)
                span.update(
                    metadata={"langchain_kind": "agent"},
                    **({"output": return_values} if return_values is not None else {}),
                )
        except Exception:
            logger.debug("atlan_ai: on_agent_finish failed", exc_info=True)
