"""Generated from schema/agent-sdk.v1.yaml — DO NOT EDIT.

Regenerate with: python scripts/gen_semconv.py
"""

from __future__ import annotations

SCHEMA_VERSION = "agent-sdk.v1"

SPAN_TYPES: tuple[str, ...] = ("task", "llm", "tool", "function", "score", "session", "turn")
SPAN_TYPE_ALIASES: dict[str, str] = {
    "generation": "llm",
    "span": "task",
}
OBSERVATION_LEVELS: tuple[str, ...] = ("DEBUG", "DEFAULT", "WARNING", "ERROR")
SCORE_DATA_TYPES: tuple[str, ...] = ("NUMERIC", "CATEGORICAL", "BOOLEAN")

# Attribute name constants (deduped across resource and span registries).
ATLAN_COMPLETION_START_TIME = "atlan.completion_start_time"
ATLAN_CONSENT_STORE_CONTENT = "atlan.consent.store_content"
ATLAN_ENVIRONMENT = "atlan.environment"
ATLAN_INPUT = "atlan.input"
ATLAN_INTERNAL_AS_ROOT = "atlan.internal.as_root"
ATLAN_OBSERVATION_LEVEL = "atlan.observation.level"
ATLAN_OBSERVATION_STATUS_MESSAGE = "atlan.observation.status_message"
ATLAN_OUTPUT = "atlan.output"
ATLAN_SDK_LANGUAGE = "atlan.sdk.language"
ATLAN_SDK_SCHEMA_VERSION = "atlan.sdk.schema_version"
ATLAN_SDK_VERSION = "atlan.sdk.version"
ATLAN_SPAN_TYPE = "atlan.span.type"
ATLAN_TAGS = "atlan.tags"
ATLAN_TRACE_NAME = "atlan.trace.name"
GEN_AI_INPUT_MESSAGES = "gen_ai.input.messages"
GEN_AI_OUTPUT_MESSAGES = "gen_ai.output.messages"
GEN_AI_PROVIDER_NAME = "gen_ai.provider.name"
GEN_AI_REQUEST_MODEL = "gen_ai.request.model"
GEN_AI_RESPONSE_ID = "gen_ai.response.id"
GEN_AI_RESPONSE_MODEL = "gen_ai.response.model"
GEN_AI_SYSTEM_INSTRUCTIONS = "gen_ai.system_instructions"
GEN_AI_TOOL_CALL_ARGUMENTS = "gen_ai.tool.call.arguments"
GEN_AI_TOOL_CALL_ID = "gen_ai.tool.call.id"
GEN_AI_TOOL_CALL_RESULT = "gen_ai.tool.call.result"
GEN_AI_TOOL_NAME = "gen_ai.tool.name"
GEN_AI_TOOL_TYPE = "gen_ai.tool.type"
GEN_AI_USAGE_CACHE_CREATION_INPUT_TOKENS = "gen_ai.usage.cache_creation.input_tokens"
GEN_AI_USAGE_CACHE_READ_INPUT_TOKENS = "gen_ai.usage.cache_read.input_tokens"
GEN_AI_USAGE_COST = "gen_ai.usage.cost"
GEN_AI_USAGE_INPUT_COST = "gen_ai.usage.input_cost"
GEN_AI_USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
GEN_AI_USAGE_OUTPUT_COST = "gen_ai.usage.output_cost"
GEN_AI_USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
GEN_AI_USAGE_TOTAL_TOKENS = "gen_ai.usage.total_tokens"
ORG_NAME = "org.name"
SERVICE_NAME = "service.name"
SESSION_ID = "session.id"
USER_EMAIL = "user.email"
USER_ID = "user.id"

RESOURCE_ATTRIBUTE_TYPES: dict[str, str] = {
    "service.name": "string",
    "atlan.sdk.schema_version": "string",
    "atlan.sdk.language": "string",
    "atlan.sdk.version": "string",
    "atlan.consent.store_content": "bool",
    "atlan.environment": "string",
    "user.id": "string",
    "user.email": "string",
    "org.name": "string",
}
RESOURCE_ATTRIBUTE_OWNERS: dict[str, str] = {
    "service.name": "app",
    "atlan.sdk.schema_version": "sdk",
    "atlan.sdk.language": "sdk",
    "atlan.sdk.version": "sdk",
    "atlan.consent.store_content": "sdk",
    "atlan.environment": "app",
    "user.id": "gateway",
    "user.email": "gateway",
    "org.name": "gateway",
}
SPAN_ATTRIBUTE_TYPES: dict[str, str] = {
    "atlan.span.type": "string",
    "atlan.trace.name": "string",
    "atlan.internal.as_root": "bool",
    "atlan.observation.level": "string",
    "atlan.observation.status_message": "string",
    "atlan.completion_start_time": "string",
    "session.id": "string",
    "user.id": "string",
    "atlan.tags": "string_list",
    "gen_ai.input.messages": "string",
    "gen_ai.output.messages": "string",
    "gen_ai.system_instructions": "string",
    "atlan.input": "string",
    "atlan.output": "string",
    "gen_ai.request.model": "string",
    "gen_ai.response.model": "string",
    "gen_ai.provider.name": "string",
    "gen_ai.response.id": "string",
    "gen_ai.usage.input_tokens": "int",
    "gen_ai.usage.output_tokens": "int",
    "gen_ai.usage.total_tokens": "int",
    "gen_ai.usage.cache_read.input_tokens": "int",
    "gen_ai.usage.cache_creation.input_tokens": "int",
    "gen_ai.usage.input_cost": "double",
    "gen_ai.usage.output_cost": "double",
    "gen_ai.usage.cost": "double",
    "gen_ai.tool.name": "string",
    "gen_ai.tool.type": "string",
    "gen_ai.tool.call.id": "string",
    "gen_ai.tool.call.arguments": "string",
    "gen_ai.tool.call.result": "string",
}
SPAN_ATTRIBUTE_OWNERS: dict[str, str] = {
    "atlan.span.type": "sdk",
    "atlan.trace.name": "app",
    "atlan.internal.as_root": "sdk",
    "atlan.observation.level": "app",
    "atlan.observation.status_message": "app",
    "atlan.completion_start_time": "sdk",
    "session.id": "app",
    "user.id": "app",
    "atlan.tags": "app",
    "gen_ai.input.messages": "app",
    "gen_ai.output.messages": "app",
    "gen_ai.system_instructions": "app",
    "atlan.input": "app",
    "atlan.output": "app",
    "gen_ai.request.model": "app",
    "gen_ai.response.model": "app",
    "gen_ai.provider.name": "app",
    "gen_ai.response.id": "app",
    "gen_ai.usage.input_tokens": "app",
    "gen_ai.usage.output_tokens": "app",
    "gen_ai.usage.total_tokens": "app",
    "gen_ai.usage.cache_read.input_tokens": "app",
    "gen_ai.usage.cache_creation.input_tokens": "app",
    "gen_ai.usage.input_cost": "app",
    "gen_ai.usage.output_cost": "app",
    "gen_ai.usage.cost": "app",
    "gen_ai.tool.name": "app",
    "gen_ai.tool.type": "app",
    "gen_ai.tool.call.id": "app",
    "gen_ai.tool.call.arguments": "app",
    "gen_ai.tool.call.result": "app",
}

# Consent gate: content-classified attributes, removed when
# atlan.consent.store_content is false. Prefix entries end with '.'.
CONTENT_ATTRIBUTES: dict[str, tuple[str, ...]] = {
    "prompts": ("gen_ai.input.messages",),
    "assistant_responses": ("gen_ai.output.messages",),
    "system_instructions": ("gen_ai.system_instructions",),
    "io": ("atlan.input", "atlan.output"),
    "tool_args": ("gen_ai.tool.call.arguments",),
    "tool_content": ("gen_ai.tool.call.result",),
    "metadata": ("atlan.metadata.",),
}

PREFIX_ATTRIBUTE_TYPES: dict[str, str] = {
    "atlan.metadata.": "dynamic",
    "atlan.score.": "double",
}

# Prefix constants (trailing dot included).
ATLAN_METADATA_PREFIX = "atlan.metadata."
ATLAN_SCORE_PREFIX = "atlan.score."

# Span events and their attribute types.
EVENT_ATTRIBUTE_TYPES: dict[str, dict[str, str]] = {
    "atlan.score": {
        "atlan.score.name": "string",
        "atlan.score.value": "double",
        "atlan.score.data_type": "string",
        "atlan.score.string_value": "string",
        "atlan.score.comment": "string",
    },
}

# Reserved for the gateway: the SDK MUST NOT emit these on the resource.
GATEWAY_OWNED_RESOURCE_ATTRIBUTES: tuple[str, ...] = ("user.id", "user.email", "org.name")
