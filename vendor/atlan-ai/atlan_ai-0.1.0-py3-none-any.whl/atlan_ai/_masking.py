"""Masking hooks (SPEC.md §8.2, §8.5). Both are fail-closed: a broken hook
drops data, it never leaks it and never breaks the host application.

Two stages:

* data-level ``mask(data=...)`` — applied to input/output/metadata/tool payloads
  at attribute-creation time; a raising hook replaces the value with
  ``MASK_FAILURE_PLACEHOLDER``.
* export-stage ``mask_otel_spans`` — sees whole export batches (including spans
  from third-party instrumentation) as immutable data and returns sparse
  patches. A raising or invalid hook drops the batch; a single invalid patch
  drops that span.
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult

logger = logging.getLogger("atlan_ai")

MASK_FAILURE_PLACEHOLDER = "[atlan: value withheld - mask hook failed]"

MaskFunction = Callable[..., Any]  # called as mask(data=value)


def apply_mask(mask: MaskFunction | None, value: object) -> object:
    if mask is None:
        return value
    try:
        return mask(data=value)
    except Exception:
        logger.warning("atlan_ai: mask function raised; value fully masked", exc_info=True)
        return MASK_FAILURE_PLACEHOLDER


@dataclass(frozen=True)
class OtelSpanIdentifier:
    trace_id: str  # 32 lowercase hex
    span_id: str  # 16 lowercase hex


@dataclass(frozen=True)
class OtelSpanData:
    identifier: OtelSpanIdentifier
    name: str
    parent_span_id: str | None
    instrumentation_scope: str
    instrumentation_scope_version: str | None
    attributes: Mapping[str, Any]
    resource_attributes: Mapping[str, Any]


@dataclass(frozen=True)
class OtelSpanPatch:
    """Sparse patch: deletes are applied before sets."""

    set_attributes: Mapping[str, Any] = field(default_factory=dict)
    delete_attributes: Sequence[str] = ()


MaskOtelSpansFunction = Callable[
    [Mapping[OtelSpanIdentifier, OtelSpanData]],
    "Mapping[OtelSpanIdentifier, OtelSpanPatch] | None",
]


def _identifier(span: ReadableSpan) -> OtelSpanIdentifier:
    context = span.context
    trace_id = context.trace_id if context else 0
    span_id = context.span_id if context else 0
    return OtelSpanIdentifier(format(trace_id, "032x"), format(span_id, "016x"))


def _span_data(span: ReadableSpan) -> OtelSpanData:
    scope = span.instrumentation_scope
    return OtelSpanData(
        identifier=_identifier(span),
        name=span.name,
        parent_span_id=format(span.parent.span_id, "016x") if span.parent else None,
        instrumentation_scope=scope.name if scope else "",
        instrumentation_scope_version=scope.version if scope else None,
        attributes=dict(span.attributes or {}),
        resource_attributes=dict(span.resource.attributes),
    )


def _valid_attribute_value(value: object) -> bool:
    if isinstance(value, (str, bool, int, float)):
        return True
    if isinstance(value, (list, tuple)):
        return all(isinstance(item, (str, bool, int, float)) for item in value)
    return False


def _clone_with_attributes(span: ReadableSpan, attributes: dict[str, Any]) -> ReadableSpan:
    return ReadableSpan(
        name=span.name,
        context=span.context,
        parent=span.parent,
        resource=span.resource,
        attributes=attributes,
        events=span.events,
        links=span.links,
        kind=span.kind,
        status=span.status,
        start_time=span.start_time,
        end_time=span.end_time,
        instrumentation_scope=span.instrumentation_scope,
    )


class MaskingSpanExporter(SpanExporter):
    """Wraps the real exporter; applies the export-stage masking hook per batch."""

    def __init__(self, wrapped: SpanExporter, hook: MaskOtelSpansFunction) -> None:
        self._wrapped = wrapped
        self._hook = hook

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        try:
            params = {data.identifier: data for data in (_span_data(span) for span in spans)}
            # Widened to `object`: user hooks may violate the declared signature.
            result: object = self._hook(params)
        except Exception:
            # Fail closed: a broken hook must never leak an unmasked batch.
            logger.error(
                "atlan_ai: mask_otel_spans raised; dropping batch of %d spans",
                len(spans),
                exc_info=True,
            )
            return SpanExportResult.SUCCESS
        if result is None:
            return self._wrapped.export(spans)
        if not isinstance(result, Mapping):
            logger.error(
                "atlan_ai: mask_otel_spans returned %s (expected mapping or None); "
                "dropping batch of %d spans",
                type(result).__name__,
                len(spans),
            )
            return SpanExportResult.SUCCESS

        kept: list[ReadableSpan] = []
        for span in spans:
            patch = result.get(_identifier(span))
            if patch is None:
                kept.append(span)
                continue
            patched = self._apply_patch(span, patch)
            if patched is not None:
                kept.append(patched)
        if not kept:
            return SpanExportResult.SUCCESS
        return self._wrapped.export(kept)

    def _apply_patch(self, span: ReadableSpan, patch: object) -> ReadableSpan | None:
        """Returns the patched span, or None to drop it (invalid patch)."""
        if not isinstance(patch, OtelSpanPatch):
            logger.warning(
                "atlan_ai: invalid patch type %s for span %r; dropping span",
                type(patch).__name__,
                span.name,
            )
            return None
        attributes: dict[str, Any] = dict(span.attributes or {})
        deletes: Sequence[object] = patch.delete_attributes
        for key in deletes:
            if not isinstance(key, str):
                logger.warning("atlan_ai: non-string delete key for %r; dropping span", span.name)
                return None
            attributes.pop(key, None)
        sets: Mapping[Any, Any] = patch.set_attributes
        for key, value in sets.items():
            if not isinstance(key, str) or not _valid_attribute_value(value):
                logger.warning(
                    "atlan_ai: invalid set_attributes entry %r for span %r; dropping span",
                    key,
                    span.name,
                )
                return None
            attributes[key] = value
        return _clone_with_attributes(span, attributes)

    def shutdown(self) -> None:
        self._wrapped.shutdown()

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return self._wrapped.force_flush(timeout_millis)
