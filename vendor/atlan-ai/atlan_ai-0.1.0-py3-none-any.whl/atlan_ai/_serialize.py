"""Safe serialization + truncation (SPEC.md §8.3-8.4).

Never raises: unknown objects degrade to str()/repr(), circular references and
excessive depth are cut off with markers, and oversized payloads are truncated
keeping the leading bytes plus an explicit suffix.
"""

from __future__ import annotations

import base64
import dataclasses
import datetime as _dt
import json
import logging
from collections.abc import Mapping, Sequence, Set
from typing import Any

logger = logging.getLogger("atlan_ai")

MAX_DEPTH = 20
TRUNCATION_SUFFIX = "...[atlan: truncated]"


def to_jsonable(value: object, _depth: int = 0, _seen: set[int] | None = None) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if _depth >= MAX_DEPTH:
        return "<max depth exceeded>"
    if _seen is None:
        _seen = set()

    if isinstance(value, (bytes, bytearray)):
        return base64.b64encode(bytes(value)).decode("ascii")
    if isinstance(value, (_dt.datetime, _dt.date, _dt.time)):
        return value.isoformat()

    # pydantic v2 / v1 models, duck-typed so pydantic is not a dependency.
    dump = getattr(value, "model_dump", None) or getattr(value, "dict", None)
    if callable(dump) and not isinstance(value, type):
        try:
            return to_jsonable(dump(), _depth + 1, _seen)
        except Exception:
            pass

    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        fields = {f.name: getattr(value, f.name) for f in dataclasses.fields(value)}
        return to_jsonable(fields, _depth + 1, _seen)

    if isinstance(value, Mapping):
        if id(value) in _seen:
            return "<circular>"
        _seen.add(id(value))
        try:
            return {str(k): to_jsonable(v, _depth + 1, _seen) for k, v in value.items()}
        finally:
            _seen.discard(id(value))
    if isinstance(value, (Sequence, Set)):
        if id(value) in _seen:
            return "<circular>"
        _seen.add(id(value))
        try:
            return [to_jsonable(item, _depth + 1, _seen) for item in value]
        finally:
            _seen.discard(id(value))

    try:
        return str(value)
    except Exception:
        return object.__repr__(value)


def truncate_utf8(text: str, max_bytes: int) -> str:
    encoded = text.encode("utf-8")
    if len(encoded) <= max_bytes:
        return text
    logger.warning(
        "atlan_ai: payload of %d bytes exceeds limit %d; truncating", len(encoded), max_bytes
    )
    return encoded[:max_bytes].decode("utf-8", errors="ignore") + TRUNCATION_SUFFIX


def serialize_payload(value: object, max_bytes: int) -> str:
    """Serialize an input/output payload to a JSON string (strings pass through)."""
    if isinstance(value, str):
        return truncate_utf8(value, max_bytes)
    try:
        rendered = json.dumps(to_jsonable(value), ensure_ascii=False, default=str)
    except Exception:
        rendered = repr(value)
    return truncate_utf8(rendered, max_bytes)


def is_message_shaped(value: object) -> bool:
    """True for a non-empty sequence of mappings that all carry a "role" key
    (SPEC.md §9.6) — routed to gen_ai.input/output.messages."""
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        return False
    if len(value) == 0:
        return False
    return all(isinstance(item, Mapping) and "role" in item for item in value)
