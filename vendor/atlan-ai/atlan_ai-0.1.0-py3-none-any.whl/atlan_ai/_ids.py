"""Trace/span ID derivation (SPEC.md §7.1-7.2).

Seeded IDs are byte-compatible with Langfuse v4's `create_trace_id` /
`_create_observation_id` (sha256 prefix), deliberately, so trace IDs match
across both backends during a dual-run migration. Conformance:
testdata/conformance/trace-id-v1.json.
"""

from __future__ import annotations

import hashlib

from opentelemetry.sdk.trace.id_generator import RandomIdGenerator

_generator = RandomIdGenerator()


def create_trace_id(seed: str | None = None) -> str:
    """Return a 32-lowercase-hex trace ID; deterministic when seeded."""
    if not seed:
        return format(_generator.generate_trace_id(), "032x")
    return hashlib.sha256(seed.encode("utf-8")).digest()[:16].hex()


def create_span_id(seed: str | None = None) -> str:
    """Return a 16-lowercase-hex span ID; deterministic when seeded."""
    if not seed:
        return format(_generator.generate_span_id(), "016x")
    return hashlib.sha256(seed.encode("utf-8")).digest()[:8].hex()
