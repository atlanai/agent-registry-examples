"""AtlanSpan — the ergonomic wrapper over an OTel span (SPEC.md §9).

Has-a, not is-a: the wrapper holds the OTel span and writes agent-sdk.v1
attributes. The observation type is set once at creation and immutable. Every
method is safe on a non-recording span (no-op posture, SPEC.md §10.1).
"""

from __future__ import annotations

import logging
from collections.abc import Mapping, Sequence

from opentelemetry import context as context_api
from opentelemetry import trace
from opentelemetry.trace import Span, StatusCode

from atlan_ai import _semconv as sc
from atlan_ai._config import Config
from atlan_ai._masking import MaskFunction, apply_mask
from atlan_ai._propagation import flatten_metadata
from atlan_ai._serialize import is_message_shaped, serialize_payload

logger = logging.getLogger("atlan_ai")

_USAGE_ATTRIBUTES = {
    "input_tokens": sc.GEN_AI_USAGE_INPUT_TOKENS,
    "output_tokens": sc.GEN_AI_USAGE_OUTPUT_TOKENS,
    "total_tokens": sc.GEN_AI_USAGE_TOTAL_TOKENS,
    "cache_read_input_tokens": sc.GEN_AI_USAGE_CACHE_READ_INPUT_TOKENS,
    "cache_creation_input_tokens": sc.GEN_AI_USAGE_CACHE_CREATION_INPUT_TOKENS,
}
_COST_ATTRIBUTES = {
    "input": sc.GEN_AI_USAGE_INPUT_COST,
    "output": sc.GEN_AI_USAGE_OUTPUT_COST,
    "total": sc.GEN_AI_USAGE_COST,
}

# Tracks the root AtlanSpan of the currently active trace so score_trace() can
# target it (SPEC.md §9.4). Set by client.start_as_current_span.
ROOT_SPAN_CONTEXT_KEY = context_api.create_key("atlan.root_span")

_SCORE_EVENT_NAME = "atlan.score"


def resolve_span_type(as_type: str) -> str:
    resolved = sc.SPAN_TYPE_ALIASES.get(as_type, as_type)
    if resolved not in sc.SPAN_TYPES:
        logger.warning("atlan_ai: unknown span type %r; using 'task'", as_type)
        return "task"
    return resolved


class AtlanSpan:
    def __init__(self, otel_span: Span, config: Config, mask: MaskFunction | None = None) -> None:
        self._otel = otel_span
        self._config = config
        self._mask = mask

    @property
    def otel_span(self) -> Span:
        return self._otel

    @property
    def trace_id(self) -> str:
        return format(self._otel.get_span_context().trace_id, "032x")

    @property
    def span_id(self) -> str:
        return format(self._otel.get_span_context().span_id, "016x")

    def _initialize(self, as_type: str, as_root: bool) -> None:
        if not self._otel.is_recording():
            return
        self._otel.set_attribute(sc.ATLAN_SPAN_TYPE, resolve_span_type(as_type))
        if as_root:
            self._otel.set_attribute(sc.ATLAN_INTERNAL_AS_ROOT, True)

    def _serialize(self, value: object) -> str:
        return serialize_payload(value, self._config.max_payload_bytes)

    def update(
        self,
        *,
        input: object = None,
        output: object = None,
        metadata: Mapping[str, object] | None = None,
        tags: Sequence[str] | None = None,
        model: str | None = None,
        response_model: str | None = None,
        provider: str | None = None,
        response_id: str | None = None,
        usage: Mapping[str, object] | None = None,
        cost: Mapping[str, object] | None = None,
        level: str | None = None,
        status_message: str | None = None,
        tool_name: str | None = None,
        tool_call_id: str | None = None,
        tool_arguments: object = None,
        tool_result: object = None,
    ) -> AtlanSpan:
        span = self._otel
        if not span.is_recording():
            return self

        content_ok = self._config.trace_content

        if input is not None and content_ok:
            masked = apply_mask(self._mask, input)
            key = sc.GEN_AI_INPUT_MESSAGES if is_message_shaped(masked) else sc.ATLAN_INPUT
            span.set_attribute(key, self._serialize(masked))
        if output is not None and content_ok:
            masked = apply_mask(self._mask, output)
            key = sc.GEN_AI_OUTPUT_MESSAGES if is_message_shaped(masked) else sc.ATLAN_OUTPUT
            span.set_attribute(key, self._serialize(masked))
        if metadata and content_ok:
            masked_metadata = apply_mask(self._mask, metadata)
            if isinstance(masked_metadata, Mapping):
                span.set_attributes(flatten_metadata(masked_metadata))
            else:
                # A mask that collapses metadata to a scalar (incl. the failure
                # placeholder) lands under the reserved `value` key.
                span.set_attributes(flatten_metadata({"value": masked_metadata}))
        if tags:
            span.set_attribute(sc.ATLAN_TAGS, tuple(str(t) for t in tags))

        if model is not None:
            span.set_attribute(sc.GEN_AI_REQUEST_MODEL, model)
        if response_model is not None:
            span.set_attribute(sc.GEN_AI_RESPONSE_MODEL, response_model)
        if provider is not None:
            span.set_attribute(sc.GEN_AI_PROVIDER_NAME, provider)
        if response_id is not None:
            span.set_attribute(sc.GEN_AI_RESPONSE_ID, response_id)

        if usage:
            for key_name, attr in _USAGE_ATTRIBUTES.items():
                value = usage.get(key_name)
                if value is None:
                    continue
                coerced = _as_int(value)
                if coerced is None:
                    logger.warning("atlan_ai: dropping non-integral usage %s=%r", key_name, value)
                    continue
                # SPEC.md §9.5: token counters MUST be OTLP IntValue.
                span.set_attribute(attr, coerced)
        if cost:
            for key_name, attr in _COST_ATTRIBUTES.items():
                value = cost.get(key_name)
                if value is None:
                    continue
                try:
                    span.set_attribute(attr, float(value))  # type: ignore[arg-type]
                except (TypeError, ValueError):
                    logger.warning("atlan_ai: dropping non-numeric cost %s=%r", key_name, value)

        if tool_name is not None:
            span.set_attribute(sc.GEN_AI_TOOL_NAME, tool_name)
        if tool_call_id is not None:
            span.set_attribute(sc.GEN_AI_TOOL_CALL_ID, tool_call_id)
        if tool_arguments is not None and content_ok:
            span.set_attribute(
                sc.GEN_AI_TOOL_CALL_ARGUMENTS,
                self._serialize(apply_mask(self._mask, tool_arguments)),
            )
        if tool_result is not None and content_ok:
            span.set_attribute(
                sc.GEN_AI_TOOL_CALL_RESULT, self._serialize(apply_mask(self._mask, tool_result))
            )

        if level is not None:
            if level not in sc.OBSERVATION_LEVELS:
                logger.warning("atlan_ai: unknown level %r; ignoring", level)
            else:
                span.set_attribute(sc.ATLAN_OBSERVATION_LEVEL, level)
                if level == "ERROR":
                    span.set_status(StatusCode.ERROR, status_message)
        if status_message is not None:
            span.set_attribute(sc.ATLAN_OBSERVATION_STATUS_MESSAGE, status_message)

        return self

    def score(
        self,
        name: str,
        value: object = None,
        data_type: str = "NUMERIC",
        string_value: str | None = None,
        comment: str | None = None,
    ) -> None:
        """Attach a score to this span (SPEC.md §9.4): an `atlan.score` event
        plus a rollup attribute `atlan.score.{name}`.

        NUMERIC requires a numeric value; CATEGORICAL requires string_value
        (numeric value defaults to 0.0); BOOLEAN encodes value as 0.0/1.0.
        Invalid scores are dropped with a warning — never raised.
        """
        span = self._otel
        if not span.is_recording():
            return
        if not name or not isinstance(name, str):
            logger.warning("atlan_ai: dropping score with invalid name %r", name)
            return
        if data_type not in sc.SCORE_DATA_TYPES:
            logger.warning("atlan_ai: dropping score %r with unknown data_type %r", name, data_type)
            return

        numeric: float
        if data_type == "NUMERIC":
            coerced = _as_float(value)
            if coerced is None:
                logger.warning(
                    "atlan_ai: dropping NUMERIC score %r with non-numeric value %r", name, value
                )
                return
            numeric = coerced
        elif data_type == "CATEGORICAL":
            if not string_value:
                logger.warning("atlan_ai: dropping CATEGORICAL score %r without string_value", name)
                return
            numeric = _as_float(value) or 0.0
        else:  # BOOLEAN
            if value is None:
                logger.warning("atlan_ai: dropping BOOLEAN score %r without value", name)
                return
            numeric = 1.0 if bool(value) else 0.0

        event_attributes: dict[str, str | float] = {
            f"{sc.ATLAN_SCORE_PREFIX}name": name,
            f"{sc.ATLAN_SCORE_PREFIX}value": numeric,
            f"{sc.ATLAN_SCORE_PREFIX}data_type": data_type,
        }
        if string_value is not None:
            event_attributes[f"{sc.ATLAN_SCORE_PREFIX}string_value"] = string_value
        if comment is not None:
            event_attributes[f"{sc.ATLAN_SCORE_PREFIX}comment"] = comment
        span.add_event(_SCORE_EVENT_NAME, event_attributes)
        span.set_attribute(f"{sc.ATLAN_SCORE_PREFIX}{name}", numeric)

    def score_trace(
        self,
        name: str,
        value: object = None,
        data_type: str = "NUMERIC",
        string_value: str | None = None,
        comment: str | None = None,
    ) -> None:
        """Attach a score to the current trace's root span when resolvable
        in-process, else to this span (SPEC.md §9.4)."""
        root = context_api.get_value(ROOT_SPAN_CONTEXT_KEY)
        target = self
        if (
            isinstance(root, AtlanSpan)
            and root is not self
            and root.trace_id == self.trace_id
            and root._otel.is_recording()
        ):
            target = root
        else:
            logger.debug("atlan_ai: score_trace falling back to the current span")
        target.score(
            name, value=value, data_type=data_type, string_value=string_value, comment=comment
        )

    def record_failure(self, error: BaseException) -> None:
        """Record an exception and mark the span ERROR (SPEC.md §9.2)."""
        if not self._otel.is_recording():
            return
        self._otel.record_exception(error)
        self.update(level="ERROR", status_message=str(error) or type(error).__name__)

    def end(self) -> None:
        self._otel.end()


def noop_span(config: Config) -> AtlanSpan:
    return AtlanSpan(trace.INVALID_SPAN, config)


def _as_int(value: object) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return None


def _as_float(value: object) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    return None
