"""Propagated attributes (SPEC.md §6).

`propagate_attributes(...)` writes values into OTel context under
`atlan.propagated.*` keys and onto the currently active span; the SDK's span
processor stamps them onto every span started inside the scope — including spans
created by third-party instrumentation.

Merge precedence (highest wins): explicit API argument on a span > nearest
enclosing scope > outer scopes. Metadata dicts merge per-key; tag lists union
with de-duplication preserving first-seen order.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Iterator, Mapping, Sequence
from contextlib import contextmanager

from opentelemetry import context as context_api
from opentelemetry import trace
from opentelemetry.context import Context

from atlan_ai import _semconv as sc

logger = logging.getLogger("atlan_ai")

_MAX_PROPAGATED_VALUE_CHARS = 200

_SESSION_ID_KEY = context_api.create_key("atlan.propagated.session_id")
_USER_ID_KEY = context_api.create_key("atlan.propagated.user_id")
_TAGS_KEY = context_api.create_key("atlan.propagated.tags")
_METADATA_KEY = context_api.create_key("atlan.propagated.metadata")
_TRACE_NAME_KEY = context_api.create_key("atlan.propagated.trace_name")

AttributeValue = str | int | bool | float | Sequence[str]


def _valid_short_string(name: str, value: object) -> str | None:
    """Runtime guard: callers may pass untyped application data."""
    if value is None:
        return None
    if not isinstance(value, str):
        logger.warning("atlan_ai: dropping non-string %s=%r", name, value)
        return None
    if len(value) > _MAX_PROPAGATED_VALUE_CHARS:
        logger.warning(
            "atlan_ai: dropping %s longer than %d chars", name, _MAX_PROPAGATED_VALUE_CHARS
        )
        return None
    return value


def _valid_tags(tags: Sequence[str] | None) -> tuple[str, ...]:
    if not tags:
        return ()
    kept: list[str] = []
    for tag in tags:
        checked = _valid_short_string("tag", tag)
        if checked is not None and checked not in kept:
            kept.append(checked)
    return tuple(kept)


def flatten_metadata(metadata: Mapping[str, object]) -> dict[str, str | int | bool]:
    """Flatten one level to `atlan.metadata.{key}` attributes (SPEC.md §6.3).

    str/int/bool values stay native (bool checked before int); everything else is
    JSON-serialized. Serialization failures degrade to repr — never raise.
    """
    flattened: dict[str, str | int | bool] = {}
    for key, value in metadata.items():
        attr = f"{sc.ATLAN_METADATA_PREFIX}{key}"
        if isinstance(value, (bool, int, str)):
            flattened[attr] = value
        else:
            try:
                flattened[attr] = json.dumps(value, ensure_ascii=False)
            except (TypeError, ValueError):
                flattened[attr] = repr(value)
    return flattened


def propagated_attributes_from_context(
    context: Context | None, include_content: bool = True
) -> dict[str, AttributeValue]:
    """Build the attribute set the processor stamps in on_start (SPEC.md §6.2).

    ``include_content=False`` (the SPEC.md §8.1 content switch) omits the
    content-classified metadata family; session/user/tags/trace-name are not
    content and are always included.
    """
    attributes: dict[str, AttributeValue] = {}
    session_id = context_api.get_value(_SESSION_ID_KEY, context)
    if isinstance(session_id, str):
        attributes[sc.SESSION_ID] = session_id
    user_id = context_api.get_value(_USER_ID_KEY, context)
    if isinstance(user_id, str):
        attributes[sc.USER_ID] = user_id
    tags = context_api.get_value(_TAGS_KEY, context)
    if isinstance(tags, tuple) and tags:
        attributes[sc.ATLAN_TAGS] = tags
    if include_content:
        metadata = context_api.get_value(_METADATA_KEY, context)
        if isinstance(metadata, dict) and metadata:
            attributes.update(flatten_metadata(metadata))
    trace_name = context_api.get_value(_TRACE_NAME_KEY, context)
    if isinstance(trace_name, str):
        attributes[sc.ATLAN_TRACE_NAME] = trace_name
    return attributes


@contextmanager
def propagate_attributes(
    *,
    session_id: str | None = None,
    user_id: str | None = None,
    tags: Sequence[str] | None = None,
    metadata: Mapping[str, object] | None = None,
    trace_name: str | None = None,
) -> Iterator[None]:
    """Attach association attributes to every span started within the scope."""
    context = context_api.get_current()

    session_id = _valid_short_string("session_id", session_id)
    if session_id is not None:
        context = context_api.set_value(_SESSION_ID_KEY, session_id, context)

    user_id = _valid_short_string("user_id", user_id)
    if user_id is not None:
        context = context_api.set_value(_USER_ID_KEY, user_id, context)

    new_tags = _valid_tags(tags)
    if new_tags:
        existing = context_api.get_value(_TAGS_KEY, context)
        merged = tuple(existing) if isinstance(existing, tuple) else ()
        merged += tuple(t for t in new_tags if t not in merged)
        context = context_api.set_value(_TAGS_KEY, merged, context)

    if metadata:
        existing_md = context_api.get_value(_METADATA_KEY, context)
        base: dict[str, object] = dict(existing_md) if isinstance(existing_md, dict) else {}
        base.update(metadata)
        context = context_api.set_value(_METADATA_KEY, base, context)

    trace_name = _valid_short_string("trace_name", trace_name)
    if trace_name is not None:
        context = context_api.set_value(_TRACE_NAME_KEY, trace_name, context)

    token = context_api.attach(context)
    # SPEC.md §6.1(b): also stamp the currently active span immediately.
    current = trace.get_current_span()
    if current.is_recording():
        current.set_attributes(propagated_attributes_from_context(context))
    try:
        yield
    finally:
        try:
            context_api.detach(token)
        except Exception:  # pragma: no cover - cross-context detach in async frameworks
            logger.debug("atlan_ai: failed to detach propagation context", exc_info=True)
