"""Atlan tracing SDK for AI agents (pre-alpha).

Phase 1-2 surface: ``init()`` / ``get_client()`` (OTel-native pipeline to the
Atlan agent gateway), spans (``start_as_current_span`` / ``start_span`` with
typed observations), the ``@observe`` decorator, seeded trace IDs, and
``propagate_attributes()`` enrichment. Scores land in Phase 4.
"""

from atlan_ai._config import AtlanConfigError
from atlan_ai._ids import create_span_id, create_trace_id
from atlan_ai._masking import (
    MASK_FAILURE_PLACEHOLDER,
    OtelSpanData,
    OtelSpanIdentifier,
    OtelSpanPatch,
)
from atlan_ai._observe import observe
from atlan_ai._propagation import propagate_attributes
from atlan_ai._semconv import SCHEMA_VERSION
from atlan_ai._span_filter import (
    default_should_export,
    is_atlan_sdk_span,
    is_genai_span,
    is_known_instrumentor_span,
)
from atlan_ai._spans import AtlanSpan
from atlan_ai._version import __version__
from atlan_ai.client import AtlanAI, get_client, init

__all__ = [
    "MASK_FAILURE_PLACEHOLDER",
    "SCHEMA_VERSION",
    "AtlanAI",
    "AtlanConfigError",
    "AtlanSpan",
    "OtelSpanData",
    "OtelSpanIdentifier",
    "OtelSpanPatch",
    "__version__",
    "create_span_id",
    "create_trace_id",
    "default_should_export",
    "get_client",
    "init",
    "is_atlan_sdk_span",
    "is_genai_span",
    "is_known_instrumentor_span",
    "observe",
    "propagate_attributes",
]
